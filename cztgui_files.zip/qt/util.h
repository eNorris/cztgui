#ifndef UTIL
#define UTIL

#include <QTime>
#include <QCoreApplication>

void delay(int millisecs);

#endif // UTIL

